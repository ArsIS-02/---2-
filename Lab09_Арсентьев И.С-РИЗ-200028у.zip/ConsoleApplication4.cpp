﻿#include <iostream>

using namespace std;

template <class T> class Tstack
{
protected:
    int numItem;
    T* item;
public:
    Tstack(size_t size = 10)
    {
        numItem = 0;
        item = new T[size];
    }

    ~Tstack()
    {
        delete[] item;
    }

    void setItem(int value)
    {
        numItem = value;
    }

    void push(T t);
    T pop(int i);
    void insertSort(long size);
};
template <class T>
void Tstack <T>::push(T t)
{
    item[numItem++] = t;

}


template <class T>
T Tstack <T>::pop(int i)
{
    return item[i];
}


template <class T>
void Tstack<T>::insertSort(long size) {
    T x;
    long i, j;

    for (i = 0; i < size; i++) {  // цикл проходов, i - номер прохода
        x = item[i];
        // поиск места элемента в готовой последовательности
        for (j = i - 1; j >= 0 && item[j] < x; j--)
            item[j + 1] = item[j];  	// сдвигаем элемент направо, пока не дошли

    // место найдено, вставить элемент
        item[j + 1] = x;
    }
}

//стек значений int, размер по умолчанию
Tstack <int> st_intl;
//стек для int на 40 элементов
Tstack <int> st_int2(40);
Tstack <long>* ptr;	//указатель, на стек для long
Tstack <double> dbl[10];	//массив стеков для double
Tstack <char*> cSt;	//стек указателей, на char
//указатель на стек для указателей на char
Tstack <char*>* ptrcSt;
void Init() //выделение памяти для переменной ptrcSt
{
    ptrcSt = new Tstack <char*>(20);
}


int main()
{
    Tstack <int> st_int(10);
    st_int.push(3);
    st_int.push(5);
    st_int.push(1);
    cout << " value of stack: ";
    for (int i = 0; i < 3; i++)
        cout << st_int.pop(i) << " ";
    cout << endl;
    st_int.insertSort(3);
    cout << " value of stack after sorting :  ";
    for (int i = 0; i < 3; i++)
        cout << st_int.pop(i) << " ";
    cout << endl;
}

