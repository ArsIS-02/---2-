﻿#include <iostream>
#include<ctype.h>
#include<fstream>
#include<stdlib.h>
using namespace std;
int main()
{
    char fname[15], c;
    cout << "Print name input file: "; cin >> fname;
    // Открыли входной файл
    ifstream  ifs(fname);
    if (!ifs)	//Проверяем поток
    {
        cout << "Not open input file " << fname;
    }
    cout << "Print name output file: ";
    cin >> fname;
    //Открытие выходного файла
    ofstream ofs(fname);
    if (!ofs)	//Проверяем поток
    {
        cout << "Not open output file: " << fname;
    }
    //Пока не произойдет ошибки, делаем:
    while (ifs && ofs)
    {
        ifs.get(c);
        // Чтение символа из файла //Переводим прочитанный символ в //верхний регистр
        c = toupper(c);
        ofs.put(c);	//Запись символа в файл
        cout << '.';
        cout << endl
            << "Output file this is  copy "
            << "input file "
            << " in upper case";
    }
}
