﻿#include <iostream>
#include<cstring>
using namespace std;
class Stroka
{
    char str[80];
public:
    Stroka(char*);
    Stroka() {}
    Stroka(const Stroka&);
    Stroka& operator=(const Stroka&);
    Stroka& operator+(const Stroka&);
    int operator==(const Stroka&);
    int dlina();
    void vvod();
    void vyvod();
};
Stroka::Stroka(char* s)
{
    strcpy(str, s);
}
Stroka::Stroka(const Stroka& s)
{
    strcpy(str, s.str);
}
Stroka& Stroka :: operator=(const Stroka& s)
{
    strcpy(str, s.str);
    return *this;
}
Stroka& Stroka :: operator+(const Stroka& s)
{
    strcat(str, s.str);
    return *this;
}
int Stroka ::operator==(const Stroka& s)
{
    if (strcmp(str, s.str) == 0)
        return 1;
    else
        return 0;
}
int Stroka::dlina()
{
    return strlen(str);
}
void Stroka::vvod()
{
    cout << "Input string>>";
    cin >> str;
}
void Stroka::vyvod()
{
    cout << str;
}


int main()
{
    Stroka s1("qwert"), s3, s4(s1), s5;
    s3.vvod();
    s3 = "asdfg";
    s3.vyvod();
    s5 = s1 + s3 + s4;
    cout << "\nlength s5 = " << s5.dlina();
    s5.vyvod();
    if (s1 == s5)
        cout << "\nstring s1 and s5 equal";
    else
        if (s1 == s4)
            cout << "\nstring s1 and s4 equal";
}
