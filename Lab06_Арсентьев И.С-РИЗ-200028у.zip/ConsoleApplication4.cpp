﻿#include <stdio.h>
#include <iostream>
#include <string.h>
using namespace std;
class Stroka
{
	char str[80];
public:
	Stroka(char*);

	Stroka() { }
	Stroka(const Stroka&);
	Stroka& operator=(const Stroka&);
	Stroka& operator+(const Stroka&);
	int operator==(const Stroka&);
	int dlina();
	void vvod();
	void vyvod();
	char* znach();
};
Stroka::Stroka(char* string)
{
	strcpy_s(str, string);
}
Stroka::Stroka(const Stroka& s)
{
	strcpy_s(str, s.str);
}
Stroka& Stroka::operator=(const Stroka& s)
{
	strcpy_s(str, s.str);
	return *this;
}
Stroka& Stroka::operator+(const Stroka& s)
{
	strcat_s(str, s.str);
	return *this;
}
int Stroka::operator==(const Stroka& s)
{
	if (strcmp(str, s.str) == 0)
		return 1;
	else
		return 0;
}
int Stroka::dlina()
{
	return strlen(str);
}
char* Stroka::znach()
{
	return str;
}
void Stroka::vvod()
{
	cin >> str;
}
void Stroka::vyvod()
{
	cout << str;
}
void main()
{
	setlocale(LC_ALL, "ru");
	char arr[] = "qwert";
	char arr1[] = "asdfg";
	Stroka s1(arr), s3, s4(s1), s5;
	//создаем экземпляр класса с использованием динамической памяти
	Stroka* s54 = new Stroka(arr);
	s3.vvod();
	s3 = arr1;
	//s3.vyvod();
	//так как s54 обьект класса Stroka* для вызова метода 
	// используется оператор ->
	s54->vyvod();
	cout << endl;
	s5 = s1 + s3 + s4;
	cout << "длина s5 = " << s5.dlina();
	cout << endl;
	s5.vyvod();
	cout << endl;
	cout << s1.znach() << endl;
	if (s1 == s5)
	{
		cout << "строки s1 и s5 равны";
		cout << endl;
	}
	else
	{
		if (s1 == s4)
			cout << "строки s1 и s4 равны";
		cout << endl;
	}
	//так как используется динамическая 
	//память ее необходимо освободить вручную
	delete s54;
}
