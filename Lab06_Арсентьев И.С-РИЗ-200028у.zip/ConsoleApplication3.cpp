﻿#include <iostream>
#include<cstring>
using namespace std;
class Stroka
{
    char str[80];
public:
    Stroka(char*);
    Stroka() {}
    Stroka(const Stroka&);
    Stroka& operator=(const Stroka&);
    Stroka& operator+(const Stroka&);
    int operator==(const Stroka&);
    int dlina();
    int dlina2(); //метод ЛР4
    int dlina3(); //метод ЛР4
    void sravn(Stroka&); //метод из ЛР4
    void konkat(Stroka&); //метод ЛР4
    void vvod();
    void vyvod();
};
Stroka::Stroka(char* s)
{
    strcpy(str, s);
}
Stroka::Stroka(const Stroka& s)
{
    strcpy(str, s.str);
}
Stroka& Stroka :: operator=(const Stroka& s)
{
    strcpy(str, s.str);
    return *this;
}
Stroka& Stroka :: operator+(const Stroka& s)
{
    strcat(str, s.str);
    return *this;
}
int Stroka ::operator==(const Stroka& s)
{
    if (strcmp(str, s.str) == 0)
        return 1;
    else
        return 0;}
int Stroka::dlina()
{
    return strlen(str);
}
int Stroka::dlina2()
{
    char* cur = str;
    for (; *cur; ++cur);
    return cur - str;
}
int Stroka::dlina3()
{
    int i;
    for (i = 0; str[i] != '\0'; i++);
    return i;
}
void Stroka::sravn(Stroka& s)
{
    int k = strcmp(str, s.str);
    switch (k)
    {
    case 0: cout << "\nstrings " << str << " and " << s.str << " are equal" << endl; break;
    case 1:cout << "\nfirst line " << str << " more" << endl; break;
    case -1: cout << "\nsecond line " << s.str << " more" << endl; break;
    }
}
void Stroka::konkat(Stroka& s)
{
    strcat(str, s.str);
}
void Stroka::vvod()
{
    cout << "\nInput string>>";
    cin >> str;
}
void Stroka::vyvod()
{
    cout << str;
}


int main()
{
    Stroka s1("qwert"), s3, s4(s1), s5;
    cout << "\nlength s1 = " << s1.dlina();
    cout << "\nlength s1 = " << s1.dlina();
    s3.vvod();
    s3 = "asdfg";
    s3.vyvod();
    s3.sravn(s1);
    s3.konkat(s1);
    s3.vyvod();
    s5 = s1 + s3 + s4;
    cout << "\nlength s5 = " << s5.dlina();
    s5.vyvod();
    if (s1 == s5)
        cout << "\nstring s1 and s5 equal";
    else
        if (s1 == s4)
            cout << "\nstring s1 and s4 equal";
}
